function [] = createMIPwithoutZ(folder_path)

%% ADD channel status also 

list_file = dir(folder_path);
cur_path = pwd;
cd(folder_path)

img = list_file(3).name;
img = imread(img);
outI = zeros(size(img));
tmp = zeros(size(img,1),size(img,2),2);
for k = 3:length(list_file)
    img = list_file(k).name;
    s = strsplit(img,'.');
    s = s{1};
    s = strsplit(s,'_');
    s = s{end};
    if isequal(s,'c001') 
      I = imread(img);
      I = double(I);    
      tmp(:,:,1) = outI;
      tmp(:,:,2) = I;
      outI = max(tmp,[],3);
    end
end

cd(cur_path)


s = strsplit(folder_path,'/');
img_name = strcat('MIP_',s{end},'.tif');

outI = uint8(outI);
imwrite(outI,strcat(cur_path,'/',img_name));


end