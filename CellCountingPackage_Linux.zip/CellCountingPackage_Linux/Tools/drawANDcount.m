function [] = drawANDcount(image_w_path, labelColor)

% Created by Tamal Batabyal

%%
I = imread(image_w_path);
R = I(:,:,1); G = I(:,:,2); B = I(:,:,3);

figure, imshow(image_w_path)

[M,N,~] = size(I);
% we need to scale each dimension to [-1, 1].
fX = @(x)(x/M)*2-1;
fY = @(y)(y/N)*2-1;
ifX = @(x)( (M*(1+x))/2 );
ifY = @(y)( (N*(1+y))/2 );

title(getString(message('SPLINES:resources:plotTitle_UseMouseToPickPoints')))


while 1
%    pts = line('Xdata',NaN,'Ydata',NaN,'marker','o','Color','c','LineWidth',1,'erase','none'); 
   pts = line('Xdata',NaN,'Ydata',NaN,'marker','o','Color','c','LineWidth',1); 
   maxpnts = 100; xy = zeros(2,maxpnts);
   
   zoom on      
   waitfor(gcf,'CurrentCharacter',char(32)) 
   zoom off
   set(gcf, 'CurrentCharacter','a') 
   
   
   
   for j=1:maxpnts
      [x,y] = ginput(1);
      if isempty(x)||x<0||x>N||y<0||y>M, break, end
      kkey = get(gcf,'CurrentCharacter');
      if (kkey == char(32) || (kkey == char(13)))
          break;          
      end
      
      xy(:,j) = [x;y];
      if j>1
         set(pts,'Xdata',xy(1,1:j),'Ydata',xy(2,1:j))
      else
         set(pts,'Xdata',x,'Ydata',y)
         xlabel(getString(message('SPLINES:resources:axesLabel_WhenYouAreDone')))
      end
   end  
    
   zoom out 
   kkey = get(gcf,'CurrentCharacter');
   if kkey == char(32)
       set(gcf, 'CurrentCharacter','a');
   end
   
   
   xlabel(getString(message('SPLINES:resources:axesLabel_ClickInsideOnce')))
   xy(:,j+1:maxpnts)=[];

   xy(:,j)=xy(:,1); %closed curve
   %set(pts,'Xdata',xy(1,:),'Ydata',xy(2,:),'erase','xor','linestyle','none')
   set(pts,'Xdata',xy(1,:),'Ydata',xy(2,:),'linestyle','none')
   
   % Drawing curve
   x = fX(xy(1,:));
   y = fY(xy(2,:));
   xyn = [x;y];
   spcv = cscvn(xyn); 
   coord = fnplt(spcv);
   
   x = ifX(coord(1,:));
   y = ifY(coord(2,:));
   
   line(x,y,'LineStyle','-','Color','c','LineWidth',1)
   % hold off
   xmin = floor(min(x));
   xmax = ceil(max(x));
   ymin = floor(min(y));
   ymax = ceil(max(y));
   [XX,YY] = meshgrid(xmin:xmax,ymin:ymax);
   
   %
   inStatus = inpolygon(XX(:),YY(:), x,y);
   XX = XX(inStatus==1); YY = YY(inStatus==1);   
   indx = sub2ind([M N],YY',XX');
  
   count = sum( (((double(R(indx))== labelColor(1)).*(double(G(indx))==labelColor(2)) ).*(double(B(indx))==labelColor(3))));
   sprintf('Region count is : %d', count)
   %count
   
   clear xmin xmax ymin ymax XX YY x y indx inStatus spcv coord xyn

   kkey = get(gcf,'CurrentCharacter');
   if (kkey==char(13))       
       break;
   else
       continue
   end
   
   
   
end 


%%
%clear pts kkey I R G B M n fX fY ifX ifY count









end