function [] = imgColorStain(path)


%%

I = imread('/home/brain_jk/Desktop/CellCountingPackage/Tamal/Final_result/count_MIP_Seq0001.tif');
figure, imshow(I)
%%
[M,N,~] = size(I);
I = double(I);

%%
a = (I(:,:,1)==255); b = (I(:,:,2)==0); c = (I(:,:,3)==0);
f = ((a.*b).*c);
[x,y] = find(f==1);
clear a b c f
%%
channel1 = I(:,:,1);
channel1 = channel1/255; % no normalization
%% NeuN
J = zeros(M,N,3);
J(:,:,1) = channel1*127;
J(:,:,2) = channel1*252;

if length(x)>0
    for k = 1:length(x)
%         J(x(k),y(k),1) = 255;
        J(x(k)-2:x(k)+2,y(k)-2:y(k)+2,1) = 255;   
%         J(x(k),y(k),2) = 0;
        J(x(k)-2:x(k)+2,y(k)-2:y(k)+2,2) = 0;      
    end
end

%% Dapi-1
J = zeros(M,N,3);
J(:,:,1) = channel1*77;
J(:,:,2) = channel1*190;
J(:,:,3) = channel1*255;
 
%% Dapi-2 (good one) you can use 12-7-200
J = zeros(M,N,3);
J(:,:,1) = channel1*10;
J(:,:,2) = channel1*80;
J(:,:,3) = channel1*255;


%%
J = zeros(M,N,3);
dp = channel1.*(channel1<0.52);
tdt = channel1.*(channel1>=0.52);

loc = find(tdt>0);
val = tdt(tdt>0);
val = (val-min(val))/(max(val)-min(val)); %0-1
val = val*0.9 + 0.1; 
tdt(loc) = val;

loc = find(dp>0);
val = dp(dp>0);
val = (val-min(val))/(max(val)-min(val)); %0-1
val = val*0.8 + 0.1; 
dp(loc) = val;


J(:,:,1) = dp*3 + tdt*255;
J(:,:,2) = dp*3 + tdt*10;
J(:,:,3) = dp*250 + tdt*0;

%% 

J = zeros(M,N,3);


if length(x)>0
    for k = 1:length(x)        
        J(x(k)-2:x(k)+2,y(k)-2:y(k)+2,1) = 255;        
    end
end


%% tdTomato

J = zeros(M,N,3);
J(:,:,1) = channel1*255;
J(:,:,2) = channel1*0;

if length(x)>0
    for k = 1:length(x)
        J(x(k),y(k),1) = 0;
        %J(x(k)-2:x(k)+2,y(k)-2:y(k)+2,2) = 255;
        J(x(k),y(k),2) = 255;
    end
end

%%

cc = [4614 2216;5020 2013;5157 2111;5314 2275; 4615 2216; 7960 2321; 8285 2324; 8448 2411;8482 2434; 8249 2148;8261 2108;...
    8059 2700; 8576 2618; 5354 2313;4700 2001; 7666 1845; 7965 2042; 8148 1820;8310 1913;8127 1962; 7933 2337; ...
    8320 2388; 7931 2337; 7570 2456;8592 2608; 8578 2597; 8236 2080; 7652 2059; ];
J = double(I);
for k = 1:length(cc)
    J(cc(k,1),cc(k,2),1) = 0;
    J(cc(k,1)-2:cc(k,1)+2,cc(k,2)-2:cc(k,2)+2,2) = 255;    
end



end