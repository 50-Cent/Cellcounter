function [] = uint8ConversionTiffStack(folder_path)

list_file = dir(folder_path);
cur_path = pwd;
cd(folder_path)
for k = 3:length(list_file)
    img = list_file(k).name;
    I = imread(img);
    I = double(I);
    I = floor( (I/max(max(I)))*255 );    
    I = uint8(I);
    imwrite(I,strcat(folder_path,'/',img));
end

cd(cur_path)

end